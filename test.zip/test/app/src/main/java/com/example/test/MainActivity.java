package com.example.test;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
   private TextView textViewHello;
   private EditText editTextInsert;
   private ImageView imageViewSlika;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textViewHello=findViewById(R.id.textViewHello);
        editTextInsert=findViewById(R.id.editTextInsert);
        imageViewSlika=findViewById(R.id.imageViewSlika);
    }
    public void clickButtonPrvi(View view){
        String text="";
        text=editTextInsert.getText().toString();
        textViewHello.setText(text);
    }
    public void clickButtonDrugi(View view){
        imageViewSlika.setImageResource(R.drawable.arsenal);
        Toast.makeText(getApplicationContext(),"Arsenal", Toast.LENGTH_SHORT).show();
    }
    public void clickButtonTreci(View view){
        imageViewSlika.setImageResource(R.drawable.liverpool);
        Toast.makeText(getApplicationContext(),"Liverpool", Toast.LENGTH_SHORT).show();
    }
}