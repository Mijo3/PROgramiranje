package com.example.konvertervaluta;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuView;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.math.RoundingMode;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    private double br,br2,br3,br4,br5,br6;
    private EditText editTextBroj;


    private TextView textViewRezultat1,textViewRezultat2,textViewRezultat3,textViewRezultat4,textViewRezultat5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextBroj=findViewById(R.id.editText);
        textViewRezultat1=findViewById(R.id.textViewRezultat1);
        textViewRezultat2=findViewById(R.id.textViewRezultat2);
        textViewRezultat3=findViewById(R.id.textViewRezultat3);
        textViewRezultat4=findViewById(R.id.textViewRezultat4);
        textViewRezultat5=findViewById(R.id.textViewRezultat5);

    }

    public void takeNumbersFromEditTextAndPutIntoVariables(){
        br= Double.parseDouble(editTextBroj.getText().toString());
    }

    public void Pretvarac(View view){
        takeNumbersFromEditTextAndPutIntoVariables();
        double rez1 = br*117.37;
        double rez2 = br*7.53;
        double rez3 = br*1.96;
        double rez4 = br*383.99;
        double rez5 = br*0.94;
        textViewRezultat1.setText(Double.toString(rez1));
        textViewRezultat2.setText(Double.toString(rez2));
        textViewRezultat3.setText(Double.toString(rez3));
        textViewRezultat4.setText(Double.toString(rez4));
        textViewRezultat5.setText(Double.toString(rez5));
    }
    public void Pretvarac2(View view){
        takeNumbersFromEditTextAndPutIntoVariables();
        double rez1 = br*0.72;
        double rez2 = br*0.0061;
        double rez3 = br*0.012;
        double rez4 = br*2.41;
        double rez5 = br*0.0060;
        textViewRezultat1.setText(Double.toString(rez1));
        textViewRezultat2.setText(Double.toString(rez2));
        textViewRezultat3.setText(Double.toString(rez3));
        textViewRezultat4.setText(Double.toString(rez4));
        textViewRezultat5.setText(Double.toString(rez5));
    }
    public void Pretvarac3(View view){
        takeNumbersFromEditTextAndPutIntoVariables();
        double rez1 = br*0.0085;
        double rez2 = br*1.40;
        double rez3 = br*0.017;
        double rez4 = br*3.36;
        double rez5 = br*0.0083;
        textViewRezultat1.setText(Double.toString(rez1));
        textViewRezultat2.setText(Double.toString(rez2));
        textViewRezultat3.setText(Double.toString(rez3));
        textViewRezultat4.setText(Double.toString(rez4));
        textViewRezultat5.setText(Double.toString(rez5));
    }
    public void Pretvarac4(View view){
        takeNumbersFromEditTextAndPutIntoVariables();
        double rez1 = br*120.03;
        double rez2 = br*167.66;
        double rez3 = br*2.00;
        double rez4 = br*403.78;
        double rez5 = br*1.03;
        textViewRezultat1.setText(Double.toString(rez1));
        textViewRezultat2.setText(Double.toString(rez2));
        textViewRezultat3.setText(Double.toString(rez3));
        textViewRezultat4.setText(Double.toString(rez4));
        textViewRezultat5.setText(Double.toString(rez5));
    }
    public void Pretvarac5(View view){
        takeNumbersFromEditTextAndPutIntoVariables();
        double rez1 = br*0.30;
        double rez2 = br*0.42;
        double rez3 = br*0.0050;
        double rez4 = br*0.0025;
        double rez5 = br*0.0025;
        textViewRezultat1.setText(Double.toString(rez1));
        textViewRezultat2.setText(Double.toString(rez2));
        textViewRezultat3.setText(Double.toString(rez3));
        textViewRezultat4.setText(Double.toString(rez4));
        textViewRezultat5.setText(Double.toString(rez5));
    }
    public void Pretvarac6(View view){
        takeNumbersFromEditTextAndPutIntoVariables();
        double rez1 = br*59.88;
        double rez2 = br*83.64;
        double rez3 = br*0.51;
        double rez4 = br*201.43;
        double rez5 = br*0.50;
        textViewRezultat1.setText(Double.toString(rez1));
        textViewRezultat2.setText(Double.toString(rez2));
        textViewRezultat3.setText(Double.toString(rez3));
        textViewRezultat4.setText(Double.toString(rez4));
        textViewRezultat5.setText(Double.toString(rez5));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
       int id=item.getItemId();
       if (id ==R.id.euro){
           setContentView(R.layout.activity_main);
       }
        if (id ==R.id.marka){
            setContentView(R.layout.marka);
            editTextBroj=findViewById(R.id.editText);
            textViewRezultat1=findViewById(R.id.textViewRezultat1);
            textViewRezultat2=findViewById(R.id.textViewRezultat2);
            textViewRezultat3=findViewById(R.id.textViewRezultat3);
            textViewRezultat4=findViewById(R.id.textViewRezultat4);
            textViewRezultat5=findViewById(R.id.textViewRezultat5);
        }
        if (id ==R.id.yen){
            setContentView(R.layout.yen);
            editTextBroj=findViewById(R.id.editText);
            textViewRezultat1=findViewById(R.id.textViewRezultat1);
            textViewRezultat2=findViewById(R.id.textViewRezultat2);
            textViewRezultat3=findViewById(R.id.textViewRezultat3);
            textViewRezultat4=findViewById(R.id.textViewRezultat4);
            textViewRezultat5=findViewById(R.id.textViewRezultat5);
        }
        if (id ==R.id.franak){
            setContentView(R.layout.franak);
            editTextBroj=findViewById(R.id.editText);
            textViewRezultat1=findViewById(R.id.textViewRezultat1);
            textViewRezultat2=findViewById(R.id.textViewRezultat2);
            textViewRezultat3=findViewById(R.id.textViewRezultat3);
            textViewRezultat4=findViewById(R.id.textViewRezultat4);
            textViewRezultat5=findViewById(R.id.textViewRezultat5);
        }
        if (id ==R.id.forinta){
            setContentView(R.layout.forinta);
            editTextBroj=findViewById(R.id.editText);
            textViewRezultat1=findViewById(R.id.textViewRezultat1);
            textViewRezultat2=findViewById(R.id.textViewRezultat2);
            textViewRezultat3=findViewById(R.id.textViewRezultat3);
            textViewRezultat4=findViewById(R.id.textViewRezultat4);
            textViewRezultat5=findViewById(R.id.textViewRezultat5);
        }
        if (id ==R.id.dinar){
            setContentView(R.layout.dinar);
            editTextBroj=findViewById(R.id.editText);
            textViewRezultat1=findViewById(R.id.textViewRezultat1);
            textViewRezultat2=findViewById(R.id.textViewRezultat2);
            textViewRezultat3=findViewById(R.id.textViewRezultat3);
            textViewRezultat4=findViewById(R.id.textViewRezultat4);
            textViewRezultat5=findViewById(R.id.textViewRezultat5);
        }

        return super.onOptionsItemSelected(item);
    }
}