package com.example.unitconverter;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    double br;
    EditText editText;
    TextView textView1,textView2,textView3,textView4,textView5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        editText= findViewById(R.id.EditText);
        textView1 = findViewById(R.id.TextView1);
        textView2 = findViewById(R.id.TextView2);
        textView3 = findViewById(R.id.TextView3);
        textView4 = findViewById(R.id.TextView4);
        textView5 = findViewById(R.id.TextView5);
    }
    public void takeNumberfromEditTextandputIntoVariables(){
        br = Double.parseDouble(editText.getText().toString());
    }
    public void Pretvorba (View view)
    {
        takeNumberfromEditTextandputIntoVariables();
        double rez1 = br * 10000;
        double rez2 = br * 1000;
        double rez3 = br * 100;
        double rez4 = br * 10;
        double rez5 = br / 1000;
        textView1.setText(Double.toString(rez1) + "dg");
        textView2.setText(Double.toString(rez2) +"g");
        textView3.setText(Double.toString(rez3) + "dag");
        textView4.setText(Double.toString(rez4) + "hg");
        textView5.setText(Double.toString(rez5) + "t");
    }
}