package com.example.kviy;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void NeTocno (View view){
     setContentView(R.layout.netocno);
    }
    public void Tocno(View view){
        setContentView(R.layout.drugopitanje);
    }
    public void Tocno2(View view){
        setContentView(R.layout.trecepitanje);
    }
    public void Tocno3(View view){
        setContentView(R.layout.cetvrtopitanje);
    }
    public void Tocno4(View view){
        setContentView(R.layout.petopitanje);
    }
    public void Tocno5(View view){
        setContentView(R.layout.sestopitanje);
    }
    public void Tocno6(View view){
        setContentView(R.layout.sedmopitanje);
    }
    public void Tocno7(View view){
        setContentView(R.layout.osmopitanje);
    }
    public void Tocno8(View view){
        setContentView(R.layout.devetopitanje);
    }
    public void Tocno9(View view){
        setContentView(R.layout.desetopitanje);
    }
    public void Tocno10(View view){
        setContentView(R.layout.kraj);
    }
    public void Povratak(View view){
        setContentView(R.layout.activity_main);
    }
    public  void Pocetak(View view) {
      setContentView(R.layout.prvopitanje);
    }
}

