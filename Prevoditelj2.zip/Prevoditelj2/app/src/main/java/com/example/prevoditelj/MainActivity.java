package com.example.prevoditelj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Spinner spinnerJezik1 , spinnerJezik2;
    TextView tekst1,tekst2,tekst3,tekst4,tekst5,tekst6,tekst7,tekst8,tekst9,tekst10;

    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinnerJezik1=findViewById(R.id.spinner_Jezik);
        spinnerJezik2=findViewById(R.id.spinner_Jezik2);
        tekst1=findViewById(R.id.textView1);
        tekst2=findViewById(R.id.textView2);
        tekst3=findViewById(R.id.textView3);
        tekst4=findViewById(R.id.textView4);
        tekst5=findViewById(R.id.textView5);
        tekst6=findViewById(R.id.textView6);
        tekst7=findViewById(R.id.textView7);
        tekst8=findViewById(R.id.textView8);
        tekst9=findViewById(R.id.textView9);
        tekst10=findViewById(R.id.textView10);
        ArrayAdapter<CharSequence>adapter=ArrayAdapter.createFromResource(this,R.array.jezici, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerJezik1.setAdapter(adapter);
        ArrayAdapter<CharSequence>adapter2=ArrayAdapter.createFromResource(this,R.array.jezici2, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerJezik2.setAdapter(adapter2);

    }
    public void Voce(View view){
        id = R.id.buttonVoce;
        if(spinnerJezik1.getSelectedItem().toString().equals("Hrvatski")){
            tekst1.setText("Jabuka");
            tekst2.setText("Banana");
            tekst3.setText("Jagoda");
            tekst4.setText("Kruška");
            tekst5.setText("Naranča");
        }
        else if(spinnerJezik1.getSelectedItem().toString().equals("Engleski")){
            tekst1.setText("Apple");
            tekst2.setText("Banana");
            tekst3.setText("Strawberry");
            tekst4.setText("Pear");
            tekst5.setText("Orange");
        }
        else if(spinnerJezik1.getSelectedItem().toString().equals("Njemački")){
            tekst1.setText("Apfel");
            tekst2.setText("Banane");
            tekst3.setText("Erdbeere");
            tekst4.setText("Birne");
            tekst5.setText("Orange");
        }
    }
    public void Povrce(View view){
        id = R.id.buttonPovrce;
        if(spinnerJezik1.getSelectedItem().toString().equals("Hrvatski")){
            tekst1.setText("Mrkva");
            tekst2.setText("Brokula");
            tekst3.setText("Salata");
            tekst4.setText("Kupus");
            tekst5.setText("Krastavac");
        }
        else if(spinnerJezik1.getSelectedItem().toString().equals("Engleski")){
            tekst1.setText("Carrot");
            tekst2.setText("Broccoli");
            tekst3.setText("Salad");
            tekst4.setText("Cabbage");
            tekst5.setText("Cucumber");
        }
        else if(spinnerJezik1.getSelectedItem().toString().equals("Njemački")){
            tekst1.setText("Karotte");
            tekst2.setText("Brokkoli");
            tekst3.setText("Salat");
            tekst4.setText("Kohl");
            tekst5.setText("Gurke");
        }
    }

    public void Namjestaj(View view){
        id = R.id.buttonNamjestaj;
        if(spinnerJezik1.getSelectedItem().toString().equals("Hrvatski")){
            tekst1.setText("Stol");
            tekst2.setText("Stolac");
            tekst3.setText("Ormar");
            tekst4.setText("Krevet");
            tekst5.setText("Kauč");
        }
        else if(spinnerJezik1.getSelectedItem().toString().equals("Engleski")){
            tekst1.setText("Table");
            tekst2.setText("Chair");
            tekst3.setText("Wardrobe");
            tekst4.setText("Bed");
            tekst5.setText("Couch");
        }
        else if(spinnerJezik1.getSelectedItem().toString().equals("Njemački")){
            tekst1.setText("Tisch");
            tekst2.setText("Stuhl");
            tekst3.setText("Kleiderschrank");
            tekst4.setText("Bett");
            tekst5.setText("Couch");
        }
    }

    public void Prevedi(View view){
        if(spinnerJezik2.getSelectedItem().toString().equals("Hrvatski")){
            if(id == R.id.buttonNamjestaj){
                tekst6.setText("Stol");
                tekst7.setText("Stolac");
                tekst8.setText("Ormar");
                tekst9.setText("Krevet");
                tekst10.setText("Kauč");
            }
            else if (id == R.id.buttonPovrce){
                tekst6.setText("Mrkva");
                tekst7.setText("Brokula");
                tekst8.setText("Salata");
                tekst9.setText("Kupus");
                tekst10.setText("Krastavac");
            }
            else if (id == R.id.buttonVoce){
                tekst6.setText("Jabuka");
                tekst7.setText("Banana");
                tekst8.setText("Jagoda");
                tekst9.setText("Kruška");
                tekst10.setText("Naranča");
            }
        }
        else if(spinnerJezik2.getSelectedItem().toString().equals("Engleski")){
            if(id == R.id.buttonNamjestaj){
                tekst6.setText("Table");
                tekst7.setText("Chair");
                tekst8.setText("Wardrobe");
                tekst9.setText("Bed");
                tekst10.setText("Couch");
            }
            else if (id == R.id.buttonPovrce){
                tekst6.setText("Carrot");
                tekst7.setText("Broccoli");
                tekst8.setText("Salad");
                tekst9.setText("Cabbage");
                tekst10.setText("Cucumber");
            }
            else if (id == R.id.buttonVoce){
                tekst6.setText("Apple");
                tekst7.setText("Banana");
                tekst8.setText("Strawberry");
                tekst9.setText("Pear");
                tekst10.setText("Orange");
            }
        }
        else if(spinnerJezik2.getSelectedItem().toString().equals("Njemački")){
            if(id == R.id.buttonNamjestaj){
                tekst6.setText("Tisch");
                tekst7.setText("Stuhl");
                tekst8.setText("Kleiderschrank");
                tekst9.setText("Bett");
                tekst10.setText("Couch");
            }
            else if (id == R.id.buttonPovrce){
                tekst6.setText("Karotte");
                tekst7.setText("Brokkoli");
                tekst8.setText("Salat");
                tekst9.setText("Kohl");
                tekst10.setText("Gurke");
            }
            else if (id == R.id.buttonVoce){
                tekst6.setText("Apfel");
                tekst7.setText("Banane");
                tekst8.setText("Erdbeere");
                tekst9.setText("Birne");
                tekst10.setText("Orange");
            }
        }
    }
    }

