package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
private ImageView Slika;
private int broj;
private TextView Rez;
private ImageView mImageView;
Random rand= new Random();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Rez=findViewById(R.id.Rezultat);
        Slika=findViewById(R.id.Slika);
        mImageView=findViewById(R.id.Slika);
    }

  public void clickButtonKocka(View view){
      broj = rand. nextInt(6)+1;
      if(broj == 1){
        mImageView.setImageResource(R.drawable.jedinica);
        Rez.setText("jedinica");
      } else if (broj == 2) {
          mImageView.setImageResource(R.drawable.dvojka);
          Rez.setText("dvojka");
      } else if (broj == 3) {
          mImageView.setImageResource(R.drawable.trojka);
          Rez.setText("trojka");
      } else if (broj == 4) {
          mImageView.setImageResource(R.drawable.cetvorka);
          Rez.setText("četvorka");
      } else if (broj == 5) {
          mImageView.setImageResource(R.drawable.petica);
          Rez.setText("petica");
      } else if (broj == 6) {
          mImageView.setImageResource(R.drawable.sestica);
          Rez.setText("šestica");
      }
  }


}