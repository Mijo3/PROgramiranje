package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.math.RoundingMode;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
private double br;
private EditText editTextBroj;
private TextView textViewRezultat1,textViewRezultat2,textViewRezultat3,textViewRezultat4,textViewRezultat5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextBroj=findViewById(R.id.editText);
        textViewRezultat1=findViewById(R.id.textViewRezultat1);
        textViewRezultat2=findViewById(R.id.textViewRezultat2);
        textViewRezultat3=findViewById(R.id.textViewRezultat3);
        textViewRezultat4=findViewById(R.id.textViewRezultat4);
        textViewRezultat5=findViewById(R.id.textViewRezultat5);
    }
    public void takeNumbersFromEditTextAndPutIntoVariables(){
        br= Double.parseDouble(editTextBroj.getText().toString());
    }
  public void Pretvarac(View view){
        takeNumbersFromEditTextAndPutIntoVariables();
        double rez1 = br*117.37;
        double rez2 = br*7.53;
        double rez3 = br*1.96;
        double rez4 = br*383.99;
        double rez5 = br*0.94;
        textViewRezultat1.setText(Double.toString(rez1));
        textViewRezultat2.setText(Double.toString(rez2));
        textViewRezultat3.setText(Double.toString(rez3));
        textViewRezultat4.setText(Double.toString(rez4));
        textViewRezultat5.setText(Double.toString(rez5));
  }

}